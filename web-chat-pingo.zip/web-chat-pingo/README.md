# web-chat-pingo
Simple, fast and user-friendly chat-app using ReactJS and Firebase.
