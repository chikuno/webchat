export default function Loading() {
  return <h2>Loading....</h2>;
}
